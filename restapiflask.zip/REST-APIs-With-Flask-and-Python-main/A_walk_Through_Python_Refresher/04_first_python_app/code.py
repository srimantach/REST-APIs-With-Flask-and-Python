user_age = input("Enter your age: ")
age_number = int(user_age)

months = age_number * 12
print(f"{age_number} is equal to {months} months.")
